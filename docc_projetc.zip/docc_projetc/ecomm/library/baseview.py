from django.views import View


class BaseView(View):
    def initialize(self):
        pass
    